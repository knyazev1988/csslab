var colors = ["red", "green", "blue"];
colors.indexOf("blue");
// 2
colors.indexOf("green");
// 1

colors[2];
// "blue"
colors.indexOf("blue");
2

colors.indexOf("purple");
// -1

var insects = ["Bee", "Ant", "Bee", "Bee", "Ant"];
insects.indexOf("Bee");
// 0
