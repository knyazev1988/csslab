var landmarks = [];
landmarks.push("My house");
landmarks.push("Front path");
landmarks.push("Flickering streetlamp");
landmarks.push("Leaky fire hydrant");
landmarks.push("Fire station");
landmarks.push("Cat rescue center");
landmarks.push("My old school");
landmarks.push("My friend's house");

landmarks.pop();
// "My friend's house"
landmarks.pop();
// "My old school"
landmarks.pop();
// "Cat rescue center"
landmarks.pop();
// "Fire station"
landmarks.pop();
// "Leaky fire hydrant"
landmarks.pop();
// "Flickering streetlamp"
landmarks.pop();
// "Front path"
landmarks.pop();
// "My house"
