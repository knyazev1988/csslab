var phrases = [
  "That sounds good",
  "Yes, you should definitely do that",
  "I'm not sure that's a great idea",
  "Maybe not today?",
  "Computer says no."
];

// Should I have another milkshake?
phrases[Math.floor(Math.random() * 5)];
// "I'm not sure that's a great idea"

// Should I do my homework?
phrases[Math.floor(Math.random() * 5)];
// "Maybe not today?"
