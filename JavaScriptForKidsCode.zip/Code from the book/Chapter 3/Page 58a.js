var randomWords = ["Explosion", "Cave", "Princess", "Pen"];
var randomIndex = Math.floor(Math.random() * 4);
randomWords[randomIndex];
// "Cave"

randomWords[Math.floor(Math.random() * 4)];
// "Princess"
