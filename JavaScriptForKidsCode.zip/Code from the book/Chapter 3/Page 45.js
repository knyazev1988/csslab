var dinosaursAndNumbers = [3, "dinosaurs", ["triceratops", "stegosaurus", 3627.5], 10];

dinosaursAndNumbers[2];
// ["triceratops", "stegosaurus", 3627.5]

dinosaursAndNumbers[2][0];
// "triceratops"
