var ourFirstFunction = function () {
  console.log("Hello world!");
};

ourFirstFunction();
// Hello world!
