var double = function (number) {
  return number * 2;
};

double(3);
// 6

double(5) + double(6);
// 22

double(double(3));
// 12
