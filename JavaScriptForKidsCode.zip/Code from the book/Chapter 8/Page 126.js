var sayHelloTo = function (name) {
  console.log("Hello " + name + "!");
};

sayHelloTo("Nick");
// Hello Nick!

sayHelloTo("Lyra");
// Hello Lyra!
