var drawCats = function (howManyTimes) {
  for (var i = 0; i < howManyTimes; i++) {
    console.log(i + " =^.^=");
  }
};

drawCats(5);
// 0 =^.^=
// 1 =^.^=
// 2 =^.^=
// 3 =^.^=
// 4 =^.^=
