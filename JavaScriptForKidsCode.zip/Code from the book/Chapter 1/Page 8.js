// Draw as many cats as you want!
var drawCats = function (howManyTimes) {
  for (var i = 0; i < howManyTimes; i++) {
    console.log(i + " =^.^=");
  }
};

drawCats(10); // You can put any number here instead of 10.

// 0 =^.^=
// 1 =^.^=
// 2 =^.^=
// 3 =^.^=
// 4 =^.^=
// 5 =^.^=
// 6 =^.^=
// 7 =^.^=
// 8 =^.^=
// 9 =^.^=
