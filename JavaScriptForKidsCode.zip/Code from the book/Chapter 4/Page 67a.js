var dog = { name: "Pancake", age: 6, color: "white", bark: "Yip yap yip!" };
var cat = { name: "Harmony", age: 8, color: "tortoiseshell" };
Object.keys(dog);
// ["name", "age", "color", "bark"]
Object.keys(cat);
// ["name", "age", "color"]
