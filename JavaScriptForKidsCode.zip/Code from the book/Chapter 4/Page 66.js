var cat = {
  legs: 3,
  name: "Harmony",
  color: "Tortoiseshell"
};

cat["name"];
// "Harmony"

cat.name;
// "Harmony"
