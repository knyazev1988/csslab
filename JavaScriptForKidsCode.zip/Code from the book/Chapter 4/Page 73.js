var owedMoney = {};
owedMoney["Jimmy"] = 5;
owedMoney["Anna"] = 7;
owedMoney["Jimmy"];
// 5
owedMoney["Jinen"];
// undefined

owedMoney["Jimmy"] += 3;
owedMoney["Jimmy"];
// 8

owedMoney;
// { Jimmy: 8, Anna: 7 }
