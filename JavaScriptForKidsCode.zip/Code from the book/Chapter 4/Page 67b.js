var cat = {};
cat["legs"] = 3;
cat["name"] = "Harmony";
cat["color"] = "Tortoiseshell";
cat;
// { color: "Tortoiseshell", legs: 3, name: "Harmony" }
