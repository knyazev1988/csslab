var dog = {
  name: "Pancake",
  legs: 4,
  isAwesome: true
};
dog.isBrown;