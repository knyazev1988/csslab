var cat = {
  legs: 3,
  name: "Harmony",
  color: "Tortoiseshell"
};

var cat = {
  legs: 3,
  "full name": "Harmony Philomena Snuggly-Pants Morgan",
  color: "Tortoiseshell"
};