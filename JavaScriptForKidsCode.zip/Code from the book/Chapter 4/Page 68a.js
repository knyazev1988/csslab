var cat = {};
cat.legs = 3;
cat.name = "Harmony";
cat.color = "Tortoiseshell";