var timeUp = function () {
  alert("Time's up!");
};

setTimeout(timeUp, 3000);
// 1

setTimeout(timeUp, 5000);
// 2
