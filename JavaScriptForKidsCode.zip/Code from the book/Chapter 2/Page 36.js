var stringNumber = "5";
var actualNumber = 5;
stringNumber === actualNumber;
// false

stringNumber == actualNumber;
// true

0 == false;
// true

"false" == false;
// false
