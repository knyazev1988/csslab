var longString = "My long string is long";
longString.slice(3, 14);
// "long string"

var longString = "My long string is long";
longString.slice(3);
// "long string is long"
