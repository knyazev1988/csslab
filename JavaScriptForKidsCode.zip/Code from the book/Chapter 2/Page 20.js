var secondsInAMinute = 60;
var minutesInAnHour = 60;
var secondsInAnHour = secondsInAMinute * minutesInAnHour;
secondsInAnHour;
// 3600

var hoursInADay = 24;
var secondsInADay = secondsInAnHour * hoursInADay;
secondsInADay;
// 86400

var daysInAYear = 365;
var secondsInAYear = secondsInADay * daysInAYear;
secondsInAYear;
// 31536000

var age = 29;
age * secondsInAYear;
// 914544000
