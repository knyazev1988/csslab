var height = 65;
var heightRestriction = 60;
height > heightRestriction;
// true

var height = 60;
var heightRestriction = 60;
height > heightRestriction;
// false

var height = 60;
var heightRestriction = 60;
height >= heightRestriction;
// true

var height = 60;
var heightRestriction = 48;
height < heightRestriction;
// false

var height = 48;
var heightRestriction = 48;
height <= heightRestriction;
// true
