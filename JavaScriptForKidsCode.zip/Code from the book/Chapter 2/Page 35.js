var mySecretNumber = 5;
var chicoGuess = 3;
mySecretNumber === chicoGuess;
// false

var harpoGuess = 7;
mySecretNumber === harpoGuess;
// false

var grouchoGuess = 5;
mySecretNumber === grouchoGuess;
// true
